# Asie à table — Android V4

Application Android native légère contenant **61 recettes asiatiques détaillées**.

## Ce qui est déjà intégré
- Android 16 / API 36
- application autonome : recettes embarquées dans l'APK
- recherche par nom, traduction française, ingrédient et mot-clé
- filtres pays et difficulté
- favoris persistants
- réglage des portions avec recalcul des quantités numériques
- liste de courses persistante avec regroupement des quantités compatibles
- sous-recettes liées
- source de chaque recette
- aucune création de compte obligatoire
- aucun minuteur, réseau social, nutrition ou fonction superflue

## Compilation APK
Le dépôt contient `.github/workflows/build-apk.yml`.

Sur GitHub, l'action installe automatiquement :
- Android SDK API 36
- Build Tools 36.0.0
- Java 17
- Gradle 9.5
- Android Gradle Plugin 9.3.1

Puis elle génère `app-debug.apk` comme artefact téléchargeable.

## Android Studio
Le projet peut aussi être ouvert directement dans Android Studio et compilé avec **Build > Build APK(s)**.

## Installation personnelle
L'APK de debug produit par la CI est signé automatiquement avec la clé de debug Android et peut être installé manuellement sur un téléphone Android après autorisation des « applications inconnues » pour l'application utilisée pour ouvrir le fichier.

Package : `com.asieatable.recettes`
Version : 4.0
minSdk : 26
targetSdk : 36
compileSdk : 36
